<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function pre_install() {
    // Debug file
    $debug_file = 'custom/rocket_debug.log';
    file_put_contents($debug_file, date('Y-m-d H:i:s') . " - pre_install() called\n", FILE_APPEND);
    
    // Debug: log all request parameters
    file_put_contents($debug_file, "REQUEST parameters: " . print_r($_REQUEST, true) . "\n", FILE_APPEND);
    
    // Check if this is the commit phase and we have a saved config
    if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'UpgradeWizard_commit') {
        file_put_contents($debug_file, "Commit phase detected, checking for saved config\n", FILE_APPEND);
        
        $config_file = getcwd() . '/custom/rocket_install_config.tmp';
        if (file_exists($config_file)) {
            $config_json = file_get_contents($config_file);
            $config = json_decode($config_json, true);
            file_put_contents($debug_file, "Found saved config: " . print_r($config, true) . "\n", FILE_APPEND);
            
            // Apply the configuration now
            file_put_contents($debug_file, "Applying configuration to source files\n", FILE_APPEND);
            replacePlaceholdersInSourceFiles($config);
            
            // Keep config for post_install
            $_SESSION['rc_install_config'] = $config;
            
            return;
        } else {
            file_put_contents($debug_file, "No saved config found at commit phase\n", FILE_APPEND);
        }
        return;
    }
    
    if (isset($_REQUEST['rc_install_submitted']) && $_REQUEST['rc_install_submitted'] == '1') {
        file_put_contents($debug_file, "Form submitted detected\n", FILE_APPEND);
        
        $config = array(
            'rc_url' => $_REQUEST['rc_rocketchat_url'],
            'admin_id' => $_REQUEST['rc_admin_id'],
            'admin_token' => $_REQUEST['rc_admin_token'],
            'oauth_id' => $_REQUEST['rc_oauth_id'],
            'oauth_secret' => $_REQUEST['rc_oauth_secret'],
            'overwrite_tpl' => isset($_REQUEST['overwrite_tpl']) ? 1 : 0,
            'overwrite_htaccess' => isset($_REQUEST['overwrite_htaccess']) ? 1 : 0
        );
        
        file_put_contents($debug_file, "Config prepared: " . print_r($config, true) . "\n", FILE_APPEND);
        
        // Save config to temporary file instead of session  
        $config_dir = getcwd() . '/custom';
        if (!is_dir($config_dir)) {
            mkdir($config_dir, 0755, true);
            file_put_contents($debug_file, "Created custom directory: $config_dir\n", FILE_APPEND);
        }
        
        $config_file = $config_dir . '/rocket_install_config.tmp';
        $json_data = json_encode($config);
        
        file_put_contents($debug_file, "Attempting to save to: $config_file\n", FILE_APPEND);
        
        if (file_put_contents($config_file, $json_data)) {
            file_put_contents($debug_file, "Config saved successfully to temp file\n", FILE_APPEND);
        } else {
            file_put_contents($debug_file, "Failed to save config to temp file\n", FILE_APPEND);
        }
        
        // Also save to session as backup
        $_SESSION['rc_install_config'] = $config;
        file_put_contents($debug_file, "Config also saved to session\n", FILE_APPEND);
        
        // IMMEDIATELY replace placeholders in files that will be copied
        file_put_contents($debug_file, "Starting immediate placeholder replacement\n", FILE_APPEND);
        replacePlaceholdersInSourceFiles($config);
        
        // Redirect to continue installation
        file_put_contents($debug_file, "Redirecting to continue installation\n", FILE_APPEND);
        
        if(empty($_REQUEST['install_file']) && isset($_SESSION['install_file_path'])){
             $_REQUEST['install_file'] = $_SESSION['install_file_path'];
        }
        
        // Continue with the normal upgrade wizard flow
        $_REQUEST['mode'] = 'Install';
        
        // Show success message instead of form
        echo '<div style="background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; margin: 20px auto; max-width: 800px; border-radius: 5px;">';
        echo '<h3>Configuration Saved Successfully!</h3>';
        echo '<p>Your Rocket.Chat configuration has been saved and applied. The installation will continue automatically.</p>';
        echo '</div>';
        
        return;
    }

    file_put_contents($debug_file, "No form submission detected, showing form\n", FILE_APPEND);
    displayInstallForm();   
}

function displayInstallForm() {
    $install_file = '';
    if (isset($_REQUEST['install_file']) && !empty($_REQUEST['install_file'])) {
        $install_file = $_REQUEST['install_file'];
        $_SESSION['install_file_path'] = $install_file;
    } elseif (isset($_SESSION['install_file_path'])) {
        $install_file = $_SESSION['install_file_path'];
    }

    $mode = 'install'; 
    
    echo '
    <style>
        .rc-box { background: #f5f5f5; border: 1px solid #ccc; padding: 20px; margin: 20px auto; max-width: 800px; border-radius: 5px; font-family: Arial, sans-serif; }
        .rc-note { background: #e8f4f8; padding: 10px; font-size: 0.9em; color: #00529b; border-left: 4px solid #00529b; margin-bottom: 20px; }
        .rc-row { margin-bottom: 15px; }
        .rc-label { font-weight: bold; display: block; margin-bottom: 5px; color: #333; }
        .rc-input { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 3px; box-sizing: border-box; }
        .rc-btn { background: #E61718; color: #fff; border: none; padding: 10px 20px; font-weight: bold; cursor: pointer; font-size: 14px; }
        .rc-btn:hover { background: #c20f10; }
        .rc-checkbox-group { background: #fff; padding: 10px; border: 1px solid #ddd; margin-bottom: 15px; }
        .rc-checkbox-label { display: flex; align-items: center; margin-bottom: 5px; cursor: pointer; }
        .rc-checkbox-label input { margin-right: 10px; }
        h2 { border-bottom: 2px solid #E61718; padding-bottom: 10px; margin-top: 0; }
    </style>
    ';

    echo '<div class="rc-box">';
    echo '<h2>Configuration Rocket.Chat Integration</h2>';

    echo '<div class="rc-note">';
    echo '<strong>How to obtain credentials:</strong><br><br>';
    echo '<strong>1. User ID and Token:</strong><br>';
    echo '- Log in to Rocket.Chat (Admin) -> Avatar -> <strong>My Account</strong>.<br>';
    echo '- Select <strong>Personal Access Tokens</strong> -> Create new token.<br>';
    echo '- Copy <strong>User ID</strong> and <strong>Token</strong> immediately.<br><br>';
    echo '<strong>2. OAuth Client ID and Secret:</strong><br>';
    echo '- Go to <strong>Admin</strong> > <strong>OAuth2 Clients and Tokens</strong> > <strong>New Authorization Client</strong>.<br>';
    echo '- Create new client (ensure <strong>Is confidential</strong> is ticked).<br>';
    echo '- Input the generated ID and Secret below.';
    echo '</div>';

    if(empty($install_file)) {
        echo '<div style="color:red; font-weight:bold; margin-bottom:10px;">Warning: Lost install_file session. Installation might fail. Please try again.</div>';
    }

    echo '<form method="POST" action="index.php?module=Administration&view=module&action=UpgradeWizard">';
    
    echo '<input type="hidden" name="mode" value="'.$mode.'">';
    echo '<input type="hidden" name="install_file" value="'.$install_file.'">';
    echo '<input type="hidden" name="rc_install_submitted" value="1">';
    
    // Add a flag to continue with installation after config
    echo '<input type="hidden" name="continue_install" value="1">';

    echo '<div class="rc-row"><label class="rc-label">Rocket.Chat URL:</label>';
    echo '<input type="text" name="rc_rocketchat_url" class="rc-input" required placeholder="https://your-rocketchat.com"></div>';

    echo '<div class="rc-row"><label class="rc-label">Rocket.Chat Admin User ID:</label>';
    echo '<input type="text" name="rc_admin_id" class="rc-input" required></div>';

    echo '<div class="rc-row"><label class="rc-label">Rocket.Chat Admin Token:</label>';
    echo '<input type="text" name="rc_admin_token" class="rc-input" required></div>';

    echo '<hr>';
    echo '<div class="rc-row"><label class="rc-label">OAuth Client ID:</label>';
    echo '<input type="text" name="rc_oauth_id" class="rc-input" required></div>';

    echo '<div class="rc-row"><label class="rc-label">OAuth Client Secret:</label>';
    echo '<input type="text" name="rc_oauth_secret" class="rc-input" required></div>';

    echo '<h4>Installation Options</h4>';
    echo '<div class="rc-checkbox-group">';
    echo '<label class="rc-checkbox-label"><input type="checkbox" name="overwrite_tpl" value="1" checked> Overwrite _headerModuleList.tpl and footer.tpl</label>';
    echo '<label class="rc-checkbox-label"><input type="checkbox" name="overwrite_htaccess" value="1" checked> Overwrite .htaccess</label>';
    echo '</div>';

    echo '<div class="rc-row"><input type="submit" value="PROCEED INSTALLATION" class="rc-btn"></div>';
    
    echo '</form>';
    echo '</div>';
}

function replacePlaceholdersInSourceFiles($config) {
    $debug_file = 'custom/rocket_debug.log';
    
    $replacements = array(
        '${rc_rocketchat_url}' => rtrim($config['rc_url'], '/'),
        '${rc_website}' => rtrim($config['rc_url'], '/'),
        '${rc_admin_user_id}' => $config['admin_id'],
        '${rc_admin_token}' => $config['admin_token'],
        '${rc_oauth_client_id}' => $config['oauth_id'],
        '${rc_oauth_client_secret}' => $config['oauth_secret']
    );

    file_put_contents($debug_file, "Replacements: " . print_r($replacements, true) . "\n", FILE_APPEND);

    // Find source files in the installer package
    $installer_dir = dirname(__FILE__) . '/../files/custom';
    file_put_contents($debug_file, "Looking for source files in: $installer_dir\n", FILE_APPEND);
    
    $source_files = array(
        $installer_dir . '/public/api/get_rc_users.php',
        $installer_dir . '/public/data/client_secret_oauth.json'
    );
    
    // Only process template files if user wants to overwrite
    if (isset($config['overwrite_tpl']) && $config['overwrite_tpl'] == 1) {
        $source_files[] = $installer_dir . '/themes/SuiteP/tpls/_headerModuleList.tpl';
        $source_files[] = $installer_dir . '/themes/SuiteP/tpls/footer.tpl';
    }

    foreach ($source_files as $source_file) {
        file_put_contents($debug_file, "Processing source file: $source_file\n", FILE_APPEND);
        
        if (file_exists($source_file)) {
            $content = file_get_contents($source_file);
            $original_content = $content;
            
            foreach ($replacements as $search => $replace) {
                $content = str_replace($search, $replace, $content);
            }
            
            if ($content !== $original_content) {
                if (file_put_contents($source_file, $content)) {
                    file_put_contents($debug_file, "Updated source file: $source_file\n", FILE_APPEND);
                } else {
                    file_put_contents($debug_file, "Failed to update source file: $source_file\n", FILE_APPEND);
                }
            } else {
                file_put_contents($debug_file, "No placeholders found in: $source_file\n", FILE_APPEND);
            }
        } else {
            file_put_contents($debug_file, "Source file not found: $source_file\n", FILE_APPEND);
        }
    }
}
?>