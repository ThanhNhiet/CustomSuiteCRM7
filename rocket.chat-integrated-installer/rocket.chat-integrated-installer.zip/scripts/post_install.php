<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

function post_install() {
    global $sugar_config;

    // Debug: Write debug info to file
    $debug_file = 'custom/rocket_debug.log';
    file_put_contents($debug_file, date('Y-m-d H:i:s') . " - post_install() called\n", FILE_APPEND);
    
    $config = null;
    
    // Try to read config from temporary file first
    $config_file = getcwd() . '/custom/rocket_install_config.tmp';
    file_put_contents($debug_file, "Looking for config file at: $config_file\n", FILE_APPEND);
    
    if (file_exists($config_file)) {
        $config_json = file_get_contents($config_file);
        $config = json_decode($config_json, true);
        file_put_contents($debug_file, "Config loaded from temp file: " . print_r($config, true) . "\n", FILE_APPEND);
        // Clean up temp file
        unlink($config_file);
        file_put_contents($debug_file, "Temp file deleted\n", FILE_APPEND);
    } else {
        file_put_contents($debug_file, "Temp config file not found\n", FILE_APPEND);
    }
    
    // Fallback to session if temp file doesn't exist
    if (!$config && isset($_SESSION['rc_install_config'])) {
        $config = $_SESSION['rc_install_config'];
        file_put_contents($debug_file, "Config loaded from session: " . print_r($config, true) . "\n", FILE_APPEND);
    }
    
    if ($config) {
        // Debug logging
        if (isset($GLOBALS['log'])) {
            $GLOBALS['log']->info("Rocket.Chat Integration: Starting placeholder replacement");
            $GLOBALS['log']->info("Rocket.Chat Integration: Config data: " . print_r($config, true));
        }
        
        $replacements = array(
            '${rc_rocketchat_url}' => rtrim($config['rc_url'], '/'),
            '${rc_website}' => rtrim($config['rc_url'], '/'),
            '${rc_admin_user_id}' => $config['admin_id'],
            '${rc_admin_token}' => $config['admin_token'],
            '${rc_oauth_client_id}' => $config['oauth_id'],
            '${rc_oauth_client_secret}' => $config['oauth_secret']
        );

        // Always replace these core files regardless of checkboxes
        $files_to_update = array(
            'custom/public/api/get_rc_users.php',
            'custom/public/api/get_secret_oauth.php', 
            'custom/public/api/custom_identity.php',
            'custom/public/data/client_secret_oauth.json'
        );

        // Only add template files if user chose to overwrite
        if (isset($config['overwrite_tpl']) && $config['overwrite_tpl'] == 1) {
            $files_to_update[] = 'custom/themes/SuiteP/tpls/_headerModuleList.tpl';
            $files_to_update[] = 'custom/themes/SuiteP/tpls/footer.tpl';
            $files_to_update[] = 'themes/SuiteP/tpls/_headerModuleList.tpl';
            $files_to_update[] = 'themes/SuiteP/tpls/footer.tpl';
        }

        // Only add htaccess if user chose to overwrite
        if (isset($config['overwrite_htaccess']) && $config['overwrite_htaccess'] == 1) {
            $files_to_update[] = '.htaccess';
        }

        file_put_contents($debug_file, "Files to update: " . print_r($files_to_update, true) . "\n", FILE_APPEND);

        $updated_count = 0;
        foreach ($files_to_update as $relative_path) {
            file_put_contents($debug_file, "Processing file: $relative_path\n", FILE_APPEND);
            if (updateFileContent($relative_path, $replacements)) {
                $updated_count++;
                file_put_contents($debug_file, "Successfully updated: $relative_path\n", FILE_APPEND);
            } else {
                file_put_contents($debug_file, "Failed to update: $relative_path\n", FILE_APPEND);
            }
        }
        
        // Clean up session if exists
        if (isset($_SESSION['rc_install_config'])) {
            unset($_SESSION['rc_install_config']);
        }
        
        echo "<h3>The file system has been automatically configured. Updated {$updated_count} files with your configuration.</h3>";
    } else {
        file_put_contents($debug_file, "No config found in temp file or session!\n", FILE_APPEND);
        echo "<h3 style='color:red'>Warning: Configuration data not found. Please update the files manually.</h3>";
    }

    require_once('modules/Administration/QuickRepairAndRebuild.php');
    $rac = new RepairAndClear();
    $rac->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), true, false);
}

function updateFileContent($relative_path, $replacements) {
    $file_path = $relative_path;
    
    if (file_exists($file_path)) {
        $content = file_get_contents($file_path);
        $original_content = $content;
        
        foreach ($replacements as $search => $replace) {
            $content = str_replace($search, $replace, $content);
        }
        
        // Check if any replacement actually happened
        if ($content !== $original_content) {
            if (file_put_contents($file_path, $content) !== false) {
                $GLOBALS['log']->info("Rocket.Chat Integration: Successfully updated config in $file_path");
                return true;
            } else {
                $GLOBALS['log']->error("Rocket.Chat Integration: Failed to write to $file_path");
                return false;
            }
        } else {
            $GLOBALS['log']->info("Rocket.Chat Integration: No placeholders found in $file_path");
            return true; // File exists but no replacement needed
        }
    } else {
        $GLOBALS['log']->error("Rocket.Chat Integration: File not found for update - $file_path");
        return false;
    }
}
?>