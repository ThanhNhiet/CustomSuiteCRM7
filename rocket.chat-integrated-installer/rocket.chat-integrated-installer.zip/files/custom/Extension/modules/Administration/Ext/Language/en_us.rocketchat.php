<?php
$mod_strings['LBL_ROCKETCHAT_TITLE'] = 'Rocket.Chat Integration';
$mod_strings['LBL_ROCKETCHAT_CONFIG'] = 'Configure Rocket.Chat Connection';
$mod_strings['LBL_ROCKETCHAT_HEADER'] = 'Rocket.Chat Settings';
?>